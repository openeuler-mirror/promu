Tarball example

Run `promu build && promu tarball` to build the binary and create a tarball.
